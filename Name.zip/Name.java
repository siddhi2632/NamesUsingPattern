import java.util.Scanner;

public class Name
{
    public static void main(String[] args)
    {
        Scanner sc =new Scanner(System.in);
        String name;
        System.out.println("Enter word..");
        name=sc.nextLine();
        int n;
        System.out.println("enter size of letter.. ");
        n=sc.nextInt();
        for(int z=0;z<name.length();z++)
        switch (name.charAt(z)) {
            case 'A','a':
                for(int i=1;i<=n;i++)//row
                {
                    for(int j=1;j<=n;j++)//column
                    {
                        if((i>1) && (j==1 || j==n) || i==(n/2)+1 || (i==1&&j>2&&j<n-1))
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    }
                    System.out.println();
                }
               System.out.println();
                break;
               
            case 'B','b':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                        if((j==1) || (i==1&&j!=n) || (i==n&&j!=n) || (i==(n/2)+1&& j!=n) || (j==n&&i>1&&i!=(n/2)+1 && i!=n))
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
                System.out.println();
            break;
            case 'C','c':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                        if(i==1 || i==n ||j==1)
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
                System.out.println();
            break;
            case 'D','d':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                    {
                        if(j==1 || (i==1&&j<n) || (i==n&&j<n) || (j==n && i!=1 &&i!=n) )
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    }
                    System.out.println();
                }
                System.out.println();
            break;
            case 'E','e':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                    {
                        if(j==1|| i==1|| i==n|| (i==(n/2)+1 && j<(n-1)))
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    }
                    System.out.println();
                }
                System.out.println();
            break;
            case 'F','f':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                    {
                        if(j==1|| i==1 || (i==(n/2)+1 && j<n-1))
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    }
                    System.out.println();
                }
                System.out.println();
            break;
            case 'G','g':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n+2;j++)
                    {
                        if(((i==1||i==n) && j!=1 && j<=n+1) || (j==1 && i!=1 &&i!=n) || ((i==(n/2)+1) && (j>=(n/2)+1))|| (j==n+2 && i>(n/2) && i<n))
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    }
                    System.out.println();
                } 
                System.out.println();
            break;
            case 'H','h':
                for(int i=1; i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                    {
                        if(j==1 || j==n|| i==(n/2)+1)
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    }
                    System.out.println();
                }
                System.out.println();
            break;
            case 'I','i':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                    {
                        if(i==1 || i==n || j==(n/2)+1)
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    }
                    System.out.println();
                }
                System.out.println();
            break;
            case 'J','j':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                        if((j==n && i<n) || (j==1&&i>=(n/2)+1 && i<n) || i==n&&j>1&&j<n)
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
                System.out.println();
            break;
            case 'K','k':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<n;j++)
                        if(j==1 || (i==(n-j)&&i<(n/2)+1) ||(i>=(n/2)+2 && j==i-1) )
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
            break;

            case 'L','l':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                        if(j==1 || i==n)
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
                System.out.println();
            break;
        
            case 'M','m':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n+2;j++)
                        if(j==1 || j==n+2|| (j==i+1 && i<=(n/2)+1)|| ((i==((n+2)-j))&&i<(n/2)+1) )
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
                System.out.println();
            break;

            case 'N','n':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n+2;j++)
                        if(j==1 || j==(n+2) || j==i+1)
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
                System.out.println();
            break;

            case 'O','o':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n+1;j++)
                        if((j==1&& i!=1&& i!=n) || (j==n+1 && i!=1 && i!=n) || (i==1&& j!=1 &&j!=n+1)|| (i==n&& j!=1&&j!=n+1)) 
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
                System.out.println();
            break;

            case 'P','p':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                        if(j==1 || (i==1&&j<n) || (i==(n/2)+1&&j<n) || (j==n&&i<(n/2)+1&&i!=1))
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
                System.out.println();
            break;

            case 'Q','q':
                for(int i=1;i<=n+2;i++)
                {
                    for(int j=1; j<=n+2;j++)
                        if((j==1&&i!=1&&i<n) || (j==n+1&&i!=1&&i<n)|| (i==1&&j!=1&&j<n+1) ||(i==n&&j!=1&&j<n+1) || (i==j&&i>=n+1))
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
                System.out.println();
            break;

            case 'R','r':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                        if(j==1|| (i==1&&j<n)|| (i==(n/2)+1&&j<n) || (j==n&&i!=1&&i!=(n/2)+1) )
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
                System.out.println();
            break;

            case 'S','s':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                        if(i==1 || i==n || i==(n/2)+1 || (j==1&&i<=(n/2)+1) || (j==n&&i>=(n/2)+1) )
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
                System.out.println();
            break;

            case 'T','t':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                        if(i==1 || j==(n/2)+1)
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
                System.out.println();
            break;

            case 'U','u':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n+1;j++)
                        if((j==1&&i!=n) || (j==n+1&&i!=n) || (i==n&&j!=1&&j!=n+1) )
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
                System.out.println();
            break;

            case 'V','v':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=(n*2)-1;j++)
                        if(i==j || j==(n*2)-i)
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                } 
                System.out.println();
            break;

            case 'W','w':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n+2;j++)
                        if(j==1 || j==n+2 || (i>=(n/2)+1&&j==i+1) || (i>(n/2)+1 && j==(n+2)-i))
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
                System.out.println();
            break;

            case 'X','x':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                        if(i==j || j==(n-i)+1)
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
                System.out.println();
            break;

            case 'Y','y':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                        if(i==j&&(j<=(n/2)+1) || (j==(n/2)+1 && i>=(n/2)+1) || (i==(n-j)+1 && j>=(n/2)+1))
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
                System.out.println();
            break;

            case 'Z','z':
                for(int i=1;i<=n;i++)
                {
                    for(int j=1;j<=n;j++)
                        if(i==1 || i==n|| i==(n-j)+1)
                            System.out.print("*");
                        else
                            System.out.print(" ");
                    System.out.println();
                }
                System.out.println();
            break;
            
        }
    }
}